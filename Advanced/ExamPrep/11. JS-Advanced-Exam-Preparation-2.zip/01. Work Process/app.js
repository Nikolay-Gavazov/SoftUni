function solve() {
    //TODO
}
solve()