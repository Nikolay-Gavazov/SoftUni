import {loadPost} from "./posts.js";

window.addEventListener('load', loadPost);
document.querySelector('nav a').addEventListener('click', loadPost)








