import {loadPost} from "./posts.js";

window.addEventListener('load', loadPost);
document.querySelector('a').addEventListener('click', loadPost)








